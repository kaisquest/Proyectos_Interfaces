---
name: SalESurf Accessible Coastal M3
colors:
  surface: '#FBF8FA'
  surface-dim: '#dcd9dc'
  surface-bright: '#fcf8fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#F0EDEF'
  surface-container-high: '#EAE7E9'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#424751'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#75777F'
  outline-variant: '#C5C6D0'
  surface-tint: '#205dae'
  primary: '#00458d'
  on-primary: '#ffffff'
  primary-container: '#76A9FF'
  on-primary-container: '#003C7D'
  inverse-primary: '#aac7ff'
  secondary: '#425e8f'
  on-secondary: '#ffffff'
  secondary-container: '#A8C4FB'
  on-secondary-container: '#345080'
  tertiary: '#735c02'
  on-tertiary: '#ffffff'
  tertiary-container: '#F8D778'
  on-tertiary-container: '#745C03'
  error: '#BA1A1A'
  on-error: '#ffffff'
  error-container: '#FFDAD6'
  on-error-container: '#93000A'
  primary-fixed: '#d7e3ff'
  primary-fixed-dim: '#aac7ff'
  on-primary-fixed: '#001b3e'
  on-primary-fixed-variant: '#00458e'
  secondary-fixed: '#d7e3ff'
  secondary-fixed-dim: '#abc7ff'
  on-secondary-fixed: '#001b3f'
  on-secondary-fixed-variant: '#294776'
  tertiary-fixed: '#ffe085'
  tertiary-fixed-dim: '#e3c467'
  on-tertiary-fixed: '#231b00'
  on-tertiary-fixed-variant: '#574500'
  background: '#F9F9FF'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  display-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system translates the maritime ruggedness of the Galician coast (Rías Baixas, Costa da Morte) into an uncompromising, high-legibility digital experience. Tailored for water sports equipment rentals and coastal surf course reservations, it merges Material 3's tonal surface model with WCAG AAA accessibility standards. Low-vision users and athletes viewing screens under intense Atlantic sunlight or misty spray require extreme edge contrast, generous tap targets, and unequivocal information hierarchy.

The design movement blends **Corporate / Modern (Material 3)** with an **Accessible High-Contrast Utility** approach:
- Surfaces are distinctly separated using crisp tonal tiers, fortified by robust borders.
- Tactile visual signifiers eliminate ambiguity for inputs, selectable dates, tides, and board rental cards.
- Tone 40 oceanic blues provide dependable grounding, balanced by high-visibility sand-gold accents for actionable, real-time alerts (wave reports, lesson slots, warnings).

## Colors

Color implementation strictly upholds WCAG AAA contrast (minimum 7:1 for normal body text, 4.5:1 for large text and interactive components):
- **Primary (`#205DAE`)**: Used for primary actionable buttons, active navigation markers, and verified indicators. Delivers >7:1 contrast on white/surface backgrounds.
- **Secondary (`#425E8F`)**: Used for supportive action chips, filter tokens, secondary button borders, and category tags.
- **Tertiary (`#735C02`)**: Used for safety indicators, tide alerts, instructor credentials, and critical highlight badges. 
- **Surfaces & Containers**: `surface` (`#FBF8FA`) and `surface-container` (`#F0EDEF`) define modular cards. Text on surfaces uses high-contrast `neutral` (`#1B1B1D`), providing an exceptional contrast ratio exceeding 13:1.
- **Outlines**: `outline` (`#75777F`) and `outline-variant` (`#C5C6D0`) ensure interactive elements maintain visible container edges even without shadow perception.

## Typography

Typography centers around **Atkinson Hyperlegible Next**, designed specifically to increase legibility for low-vision readers through distinct glyph shapes (e.g., differentiating 'I', 'l', and '1', or '0' and 'O'). 

Key principles:
- Minimum baseline body text is set to 16px (`body-md`), with 18px (`body-lg`) preferred for descriptions and instructions.
- Line heights maintain a relaxed ratio (1.5x for body text) to accommodate browser text-zooming up to 200% without clipping or collision.
- Bold weight (700) is standard for headings and actionable labels to ensure visual clarity under bright outdoor conditions.

## Layout & Spacing

A fluid responsive grid adapts smoothly across handheld devices, tablets, and desktop rental terminals:
- **Mobile (<600px)**: 4-column layout with 16px margins and 16px gutters. Every actionable target is guaranteed a minimum size of 48×48px with 8px separation to prevent mis-clicks.
- **Tablet (600px–1024px)**: 8-column layout with 32px margins and 24px gutters. Split-screen patterns support concurrent course viewing and calendar booking.
- **Desktop (>1024px)**: 12-column layout with maximum content container width of 1280px, flanked by auto-centering safety margins.

Vertical rhythm follows a strict 8px baseline module. Forms, gear specifications, and schedule tables keep high internal padding (`space-md` to `space-lg`) to prevent visual crowding.

## Elevation & Depth

This design system avoids faint, low-opacity drop shadows that vanish for low-vision users or wash out under outdoor glare. Depth is established through **Tonal Layering with Structural Outlines**:
- **Level 0 (Screen Canvas)**: `#F9F9FF` base.
- **Level 1 (Cards, Rental Listings)**: `#FBF8FA` with a solid 1px or 2px outline in `#C5C6D0`.
- **Level 2 (Active Dropdowns, Modals, Overlays)**: `#F0EDEF` paired with a directional, high-definition ambient shadow (`0px 4px 12px rgba(0, 0, 0, 0.16)`) and a defined border in `#75777F`.
- **Focus Elevation**: Interactive elements in focus receive no artificial shadow shift; instead, they gain a high-visibility, 3px solid focus ring in `#003C7D` with a 2px offset.

## Shapes

The system uses `roundedness: 2` (base radius of 0.5rem / 8px). This geometry balances modern fluid ocean motifs with structural clarity.
- Interactive buttons and inputs use 8px (`0.5rem`) corners, preserving clear boundaries.
- Badges and filter tags utilize fully rounded pills for immediate visual distinction from square action buttons.
- Surface cards use 16px (`1rem`, `rounded-lg`) corner radii to maintain friendly containment without clipping high-contrast interior borders.

## Components

### Buttons
- **Primary Action (Book / Confirm)**: Fill `#205DAE`, text `#FFFFFF`, minimum height 52px (exceeding standard 48px). Bold `label-lg`. In hover/pressed states, tone deepens to `#00356F`.
- **Secondary Action (Filter / Details)**: Surface fill with 2px stroke in `#425E8F`, text `#425E8F`.
- **Focus State**: 3px solid outline `#003C7D` offset by 2px (`outline-offset: 2px`).

### Chips & Badges
- **Experience Level / Tides**: `#F8D778` container with high-contrast `#745C03` text and icon.
- **Equipment Status**: High-contrast solid badges indicating "Available" (`#00458E` on `#D6E3FF`) or "Reserved" (`#93000A` on `#FFDAD6`).

### Cards (Course & Equipment)
- Built on `surfaceContainer` (`#F0EDEF`) with 1.5px border `#C5C6D0`.
- Structure: Clear thumbnail image with descriptive alt-text, bold 20px title, prominent equipment category pill, pricing highlighted in primary blue at 24px bold, and an explicit full-width CTA button.

### Form Inputs & Date Pickers
- **Text Inputs**: 56px height, surface background `#FFFFFF`, 2px solid border `#75777F`. Placeholder text adheres to 4.5:1 contrast minimum. Floating labels remain readable at 14px bold.
- **Error State**: 2px border in `#BA1A1A` with a dedicated warning icon and persistent text description below the field (never reliant on color alone).

### Checkboxes & Radios
- Size: 24×24px visual element contained inside a 48×48px transparent interactive target container.
- High-contrast 2.5px border with distinctive check/dot in `#205DAE`.

### Domain-Specific: Marine Weather & Tide Matrix
- High-contrast data grid with alternating accessible rows (`#FBF8FA` and `#F0EDEF`).
- Numerical tide height, water temperature, and swell periods displayed in 18px bold text with associated high-contrast direction arrows.